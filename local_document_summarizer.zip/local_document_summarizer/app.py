import streamlit as st
from summarizer import (
    check_ollama, list_local_models, summarize_document,
    DEFAULT_MODEL, OLLAMA_URL
)

st.set_page_config(
    page_title="Local Document Summarizer",
    page_icon="📄",
    layout="wide"
)

st.title("📄 Local Document Summarizer")
st.caption("Summarize your text documents privately using an Ollama-hosted language model.")

with st.sidebar:
    st.header("⚙️ Settings")
    st.write("**Runtime:** Local Ollama")
    st.write(f"**Ollama endpoint:** `{OLLAMA_URL}`")

    connected, status_message = check_ollama()
    if connected:
        st.success("Ollama is running")
    else:
        st.error("Ollama is not reachable")
        st.caption(status_message)

    available_models = list_local_models() if connected else []
    if available_models:
        default_index = available_models.index(DEFAULT_MODEL) if DEFAULT_MODEL in available_models else 0
        model = st.selectbox("Choose a local model", available_models, index=default_index)
    else:
        model = st.text_input("Model name", value=DEFAULT_MODEL)
        st.caption(f"Make sure this model is downloaded: `ollama pull {DEFAULT_MODEL}`")

    detail = st.select_slider(
        "Summary detail",
        options=["Brief", "Balanced", "Detailed"],
        value="Balanced"
    )

st.markdown("### 1. Upload your document")
uploaded_file = st.file_uploader(
    "Choose a plain-text file",
    type=["txt"],
    help="Upload a .txt file. The document is processed locally by Ollama."
)

if uploaded_file is not None:
    try:
        raw_bytes = uploaded_file.getvalue()
        try:
            document_text = raw_bytes.decode("utf-8")
        except UnicodeDecodeError:
            document_text = raw_bytes.decode("latin-1")

        document_text = document_text.strip()
        st.info(f"File: **{uploaded_file.name}** · {len(document_text):,} characters · {len(document_text.split()):,} words")

        with st.expander("Preview uploaded document"):
            st.text(document_text[:5000] + ("\n\n[Preview shortened]" if len(document_text) > 5000 else ""))

        st.markdown("### 2. Generate a structured summary")
        if not document_text:
            st.warning("The uploaded file is empty. Please upload a text file containing some content.")
        elif st.button("✨ Generate Summary", type="primary", use_container_width=True):
            if not connected:
                st.error("Ollama is not running. Start Ollama and try again.")
            else:
                with st.spinner(f"Generating a {detail.lower()} summary with {model}..."):
                    try:
                        result = summarize_document(
                            document_text=document_text,
                            model=model.strip(),
                            detail=detail
                        )
                        st.session_state["summary_result"] = result
                        st.session_state["summary_filename"] = uploaded_file.name
                    except Exception as exc:
                        st.error(f"Could not generate the summary: {exc}")
                        st.info("Check that Ollama is running and the selected model is downloaded.")
    except Exception as exc:
        st.error(f"Could not read the uploaded file: {exc}")

if "summary_result" in st.session_state:
    st.markdown("---")
    st.markdown("### 3. Generated Summary")
    st.caption(f"Source document: {st.session_state.get('summary_filename', 'Uploaded file')}")
    st.markdown(st.session_state["summary_result"])

    download_text = (
        f"DOCUMENT SUMMARY\n"
        f"Source: {st.session_state.get('summary_filename', 'Uploaded file')}\n"
        f"Generated locally using Ollama\n\n"
        f"{st.session_state['summary_result']}\n"
    )
    st.download_button(
        "⬇️ Download Summary (.txt)",
        data=download_text,
        file_name="document_summary.txt",
        mime="text/plain",
        use_container_width=True
    )

st.markdown("---")
st.caption("Privacy note: This application sends document text only to your local Ollama service. It does not use a cloud LLM API.")
