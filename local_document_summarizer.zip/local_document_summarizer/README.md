# Local Document Summarizer (Ollama + Streamlit)

A local GenAI application that accepts a `.txt` document and creates a structured summary using an LLM hosted by Ollama.

## Features

- Upload plain-text `.txt` files.
- Uses a locally hosted Ollama model (default: `llama3.2`).
- Generates a structured summary: title, overview, key points, keywords, conclusion, and possible questions.
- Brief, balanced, and detailed summary modes.
- Handles long documents by splitting them into chunks, summarizing each chunk, and combining the results.
- Preview the uploaded document and download the generated summary.
- No OpenAI API key or paid cloud LLM API required.

## Requirements

- Windows, macOS, or Linux
- Python 3.9 or newer
- Ollama installed
- A local Ollama model downloaded (default: `llama3.2`)
- Internet is needed only if you must install packages or download the model. Summarization itself runs locally.

## Setup on Windows (VS Code)

### 1. Install and start Ollama

Install Ollama from: https://ollama.com/download

Open PowerShell or the VS Code terminal and run:

```powershell
ollama pull llama3.2
```

Check that the model is available:

```powershell
ollama list
```

Ollama normally runs its local API at `http://localhost:11434`.

### 2. Open the project

Extract the ZIP file and open the `local_document_summarizer` folder in VS Code.

Open Terminal → New Terminal.

### 3. Create a virtual environment

```powershell
python -m venv venv
```

Activate it:

```powershell
.\venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt terminal and run:

```cmd
venv\Scripts\activate.bat
```

### 4. Install dependencies

```powershell
python -m pip install -r requirements.txt
```

### 5. Run the application

```powershell
python -m streamlit run app.py
```

The browser should open automatically. If it does not, open:

http://localhost:8501

Upload a `.txt` file, choose the model and summary detail, then click **Generate Summary**.

## Quick run

On Windows, after Python, dependencies, Ollama, and the model are installed, you can double-click `run.bat`.

## Troubleshooting

**Ollama is not reachable**
- Open the Ollama desktop application, or start the Ollama service.
- Check `http://localhost:11434/api/tags` in your browser.
- Keep Ollama running while using the app.

**Model not found**
```powershell
ollama pull llama3.2
ollama list
```
If you selected another model in the app, make sure that exact model name appears in `ollama list`.

**Streamlit command not found**
Use:
```powershell
python -m streamlit run app.py
```

**Summary is slow**
Local generation speed depends on your computer and model size. Try a smaller model or select Brief summary detail.

## Project structure

```text
local_document_summarizer/
│
├── app.py              # Streamlit user interface
├── summarizer.py       # Ollama API, chunking, and summarization logic
├── requirements.txt    # Python dependencies
├── sample_document.txt # Sample input for testing
├── run.bat             # Windows quick-run script
├── .gitignore
└── README.md
```

## Architecture

1. User uploads a text file through Streamlit.
2. Python reads and decodes the uploaded text.
3. Long documents are split into smaller chunks.
4. The application sends a prompt and document text to Ollama's local `/api/generate` endpoint.
5. The local LLM generates a structured summary.
6. Streamlit displays the result and provides a text download.

## Important note

This project accepts `.txt` files, as required by the problem statement. It does not upload documents to a remote AI service. The local Ollama model must already be installed and running.
