"""Local document summarization functions powered by Ollama."""
import requests

OLLAMA_URL = "http://localhost:11434"
DEFAULT_MODEL = "llama3.2"
TIMEOUT_SECONDS = 300
CHUNK_SIZE = 12000


def check_ollama():
    """Return (is_available, message) for the local Ollama server."""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        response.raise_for_status()
        return True, "Ollama server is available."
    except requests.RequestException as exc:
        return False, str(exc)


def list_local_models():
    """Return names of models downloaded in the local Ollama installation."""
    try:
        response = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        response.raise_for_status()
        data = response.json()
        return [item.get("name", "") for item in data.get("models", []) if item.get("name")]
    except (requests.RequestException, ValueError):
        return []


def split_into_chunks(text, chunk_size=CHUNK_SIZE):
    """Split long text into manageable chunks, preferably at paragraph boundaries."""
    text = text.strip()
    if len(text) <= chunk_size:
        return [text]

    chunks = []
    remaining = text
    while remaining:
        if len(remaining) <= chunk_size:
            chunks.append(remaining)
            break

        split_at = remaining.rfind("\n\n", 0, chunk_size)
        if split_at < chunk_size // 2:
            split_at = remaining.rfind(" ", 0, chunk_size)
        if split_at < chunk_size // 2:
            split_at = chunk_size

        chunks.append(remaining[:split_at].strip())
        remaining = remaining[split_at:].strip()

    return [chunk for chunk in chunks if chunk]


def call_ollama(prompt, model):
    """Call Ollama's local generate API and return the generated text."""
    response = requests.post(
        f"{OLLAMA_URL}/api/generate",
        json={
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": 0.2}
        },
        timeout=TIMEOUT_SECONDS
    )
    if response.status_code == 404:
        raise RuntimeError(
            f"Model '{model}' was not found. Download it using: ollama pull {model}"
        )
    response.raise_for_status()
    result = response.json().get("response", "").strip()
    if not result:
        raise RuntimeError("Ollama returned an empty response. Please try again.")
    return result


def build_summary_prompt(document_text, detail):
    detail_instruction = {
        "Brief": "Keep the summary concise. Use 3-5 key points.",
        "Balanced": "Provide a clear, useful summary. Use 5-8 key points.",
        "Detailed": "Provide a thorough summary. Use 8-12 key points and explain important concepts."
    }.get(detail, "Provide a balanced summary.")

    return f"""
You are a careful document summarization assistant.
Summarize ONLY the information present in the source document.
Do not invent facts. If something is not mentioned, write "Not specified in the document".
{detail_instruction}

Return the answer in exactly this readable structure:

# Document Summary
## 1. Title
Give a suitable title based on the document.

## 2. Overview
Write one short paragraph explaining the document's main purpose and message.

## 3. Key Points
List the most important points as bullet points.

## 4. Important Terms / Keywords
List important terms and briefly explain them when possible.

## 5. Conclusion
State the overall takeaway in 2-3 sentences.

## 6. Possible Questions
Write 2 useful questions that someone could ask after reading this document.

SOURCE DOCUMENT:
\"\"\"
{document_text}
\"\"\"

Write the structured summary now:
""".strip()


def summarize_document(document_text, model=DEFAULT_MODEL, detail="Balanced"):
    """Summarize short or long documents using a local Ollama model."""
    chunks = split_into_chunks(document_text)

    if len(chunks) == 1:
        return call_ollama(build_summary_prompt(chunks[0], detail), model)

    # For long documents, first summarize each part, then combine the results.
    partial_summaries = []
    for index, chunk in enumerate(chunks, start=1):
        prompt = f"""
Summarize this part of a larger document. Preserve important facts, names,
dates, definitions, and conclusions. Do not add information.

PART {index} OF {len(chunks)}:
\"\"\"
{chunk}
\"\"\"

Write a compact but informative summary of this part:
""".strip()
        partial_summaries.append(call_ollama(prompt, model))

    combined = "\n\n".join(
        f"PART {i} SUMMARY:\n{summary}"
        for i, summary in enumerate(partial_summaries, start=1)
    )
    return call_ollama(build_summary_prompt(combined, detail), model)
