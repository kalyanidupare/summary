@echo off
echo Starting Local Document Summarizer...
python -m streamlit run app.py
pause
